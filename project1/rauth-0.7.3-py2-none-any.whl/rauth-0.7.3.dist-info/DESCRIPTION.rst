rauth
-----

A simple Python OAuth 1.0/a, OAuth 2.0, and Ofly consumer library built on
top of Requests.

Links
`````
* `documentation <https://rauth.readthedocs.org/en/latest/>`_
* `development version <https://github.com/maxcountryman/rauth>`_


